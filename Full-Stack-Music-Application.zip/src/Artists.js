// CRUD
// this page will:
// create new artists
// show all artists
// edit artists by ID
// delete artists by ID

import { Link } from 'react-router-dom';
import { useState, useEffect } from 'react';
import axios from 'axios';

function Artists() {
  const [artists, setArtists] = useState([]);
  const [name, setName] = useState('');
  const [genre, setGenre] = useState('');
  const [monthlyListeners, setMonthlyListeners] = useState('');
  const [updateId, setUpdateId] = useState(null);

  const getArtists = async () => {
    const res = await axios.get('http://localhost:3001/api/artists');
    setArtists(res.data);
  };

  const addArtist = async () => {
    await axios.post('http://localhost:3001/api/artists', {
      name,
      genre,
      monthlyListeners,
    });
    getArtists();
    clearForm();
  };

  const updateArtist = async () => {
    await axios.put(`http://localhost:3001/api/artists/${updateId}`, {
      name,
      genre,
      monthlyListeners,
    });
    getArtists();
    clearForm();
  };

  const deleteArtist = async (id) => {
    await axios.delete(`http://localhost:3001/api/artists/${id}`);
    getArtists();
  };

  const clearForm = () => {
    setName('');
    setGenre('');
    setMonthlyListeners('');
    setUpdateId(null);
  };

  useEffect(() => {
    getArtists();
  }, []);

  return (
    <div className="page-container">
    <div className="nav-buttons">
<Link to="/"><button className="primary-btn">Home</button></Link>

<Link to="/songs"><button className="primary-btn">Songs</button></Link>
<Link to="/albums"><button className="primary-btn">Albums</button></Link>
</div>
      <div className="artists-container">
        <h2> Artists</h2>
        <div className="form-group">
          <input
            className="input"
            placeholder="Name"
            value={name}
            onChange={e => setName(e.target.value)}
          />
          <input
            className="input"
            placeholder="Genre"
            value={genre}
            onChange={e => setGenre(e.target.value)}
          />
          <input
            className="input"
            placeholder="Monthly Listeners"
            value={monthlyListeners}
            onChange={e => setMonthlyListeners(e.target.value)}
          />
        </div>

        <div className="button-group">
          {updateId ? (
            <button className="btn update" onClick={updateArtist}>Update Artist</button>
          ) : (
            <button className="btn add" onClick={addArtist}>Add Artist</button>
          )}
          <button className="btn clear" onClick={clearForm}>Clear</button>
        </div>

        <div className="artist-list">
          <h3>All Artists</h3>
          {artists.map((artist) => (
            <div key={artist.id} className="artist-card">
              <p>
                <strong>{artist.name}</strong> – {artist.genre} – {Number(artist.monthlyListeners).toLocaleString()} listeners
              </p>
              <div className="card-buttons">
                <button className="btn edit" onClick={() => {
                  setName(artist.name);
                  setGenre(artist.genre);
                  setMonthlyListeners(artist.monthlyListeners);
                  setUpdateId(artist.id);
                }}>Edit</button>
                <button className="btn delete" onClick={() => deleteArtist(artist.id)}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Artists;
