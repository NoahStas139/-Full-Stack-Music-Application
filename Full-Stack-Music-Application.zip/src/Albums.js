import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function Albums() {
  const [albums, setAlbums] = useState([]);
  const [title, setTitle] = useState('');
  const [releaseYear, setReleaseYear] = useState('');
  const [artistId, setArtistId] = useState('');
  const [updateId, setUpdateId] = useState(null);

  const [artists, setArtists] = useState([]);
  const [songs, setSongs] = useState([]);

  const getAlbums = async () => {
    const res = await axios.get('http://localhost:3001/api/albums');
    setAlbums(res.data);
  };

  const getArtists = async () => {
    const res = await axios.get('http://localhost:3001/api/artists');
    setArtists(res.data);
  };

  const getSongs = async () => {
    const res = await axios.get('http://localhost:3001/api/songs');
    setSongs(res.data);
  };

  const addAlbum = async () => {
    await axios.post('http://localhost:3001/api/albums', {
      title,
      releaseYear,
      artist_id: artistId
    });
    await getAlbums(); // wait for DB update before refreshing view
    clearForm();
  };

  const updateAlbum = async () => {
    await axios.put(`http://localhost:3001/api/albums/${updateId}`, {
      title,
      releaseYear,
      artist_id: artistId
    });
    await getAlbums(); // wait for DB update
    clearForm();
  };

  const deleteAlbum = async (id) => {
    await axios.delete(`http://localhost:3001/api/albums/${id}`);
    await getAlbums(); // wait for DB update
  };

  const clearForm = () => {
    setTitle('');
    setReleaseYear('');
    setArtistId('');
    setUpdateId(null);
  };

  useEffect(() => {
    getAlbums();
    getArtists();
    getSongs();
  }, []);

  return (
    <div className="page-container">
      <div className="nav-buttons">
        <Link to="/"><button className="primary-btn">Home</button></Link>
        <Link to="/artists"><button className="primary-btn">Artists</button></Link>
        <Link to="/songs"><button className="primary-btn">Songs</button></Link>
      </div>

      <div className="albums-container">
        <h2>Albums</h2>

        <div className="form-group">
          <input
            className="input-field"
            placeholder="Title"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
          <input
            className="input-field"
            placeholder="Release Year"
            value={releaseYear}
            onChange={e => setReleaseYear(e.target.value)}
          />
          <select
            className="input-field"
            value={artistId}
            onChange={e => setArtistId(e.target.value)}
          >
            <option value="">Select Artist</option>
            {artists.map(artist => (
              <option key={artist.id} value={artist.id}>
                {artist.name}
              </option>
            ))}
          </select>
        </div>

        <div className="button-group">
          {updateId ? (
            <button onClick={updateAlbum} className="add-btn">Update Album</button>
          ) : (
            <button onClick={addAlbum} className="add-btn">Add Album</button>
          )}
          <button onClick={clearForm} className="clear-btn">Clear</button>
        </div>

        <div className="album-list">
          <h3>All Albums</h3>
          {albums.map(album => {
            const albumSongs = songs.filter(song => song.album_id === album.id);

            return (
              <div key={album.id} className="card">
                <p>
                  <strong>{album.title}</strong> – {album.releaseYear} <br />
                  Artist ID: {album.artist_id}
                </p>

                {albumSongs.length > 0 && (
                  <ul>
                    {albumSongs.map(song => (
                      <li key={song.id}>
                        {song.title} – {song.duration} ({song.releaseYear})
                      </li>
                    ))}
                  </ul>
                )}

                <button
                  className="edit-btn"
                  onClick={() => {
                    setTitle(album.title);
                    setReleaseYear(album.releaseYear);
                    setArtistId(album.artist_id);
                    setUpdateId(album.id);
                  }}
                >
                  Edit
                </button>

                <button className="delete-btn" onClick={() => deleteAlbum(album.id)}>
                  Delete
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default Albums;
