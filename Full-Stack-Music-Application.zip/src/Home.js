import { Link } from 'react-router-dom';
import './style.css';

function Home() {
  return (
    <div className="container">
      <h1> Music App</h1>
      <p>Select a section to explore:</p>
      <div className="nav-buttons">
        <Link to="/artists">
          <button className="primary-btn">Artists</button>
        </Link>
        <Link to="/songs">
          <button className="primary-btn">Songs</button>
        </Link>
        <Link to="/albums">
          <button className="primary-btn">Albums</button>
        </Link>
      </div>
    </div>
  );
}

export default Home;
