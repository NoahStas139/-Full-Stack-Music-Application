import { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function Songs() {
  const [songs, setSongs] = useState([]);
  const [title, setTitle] = useState('');
  const [duration, setDuration] = useState('');
  const [releaseYear, setReleaseYear] = useState('');
  const [artistId, setArtistId] = useState('');
  const [albumId, setAlbumId] = useState('');
  const [updateId, setUpdateId] = useState(null);

  const [artists, setArtists] = useState([]);
  const [albums, setAlbums] = useState([]);

  const getSongs = async () => {
    const res = await axios.get('http://localhost:3001/api/songs');
    setSongs(res.data);
  };

  const getArtistsAndAlbums = async () => {
    const [artistsRes, albumsRes] = await Promise.all([
      axios.get('http://localhost:3001/api/artists'),
      axios.get('http://localhost:3001/api/albums'),
    ]);
    setArtists(artistsRes.data);
    setAlbums(albumsRes.data);
  };

  const addSong = async () => {
    await axios.post('http://localhost:3001/api/songs', {
      title,
      duration,
      releaseYear,
      artist_id: artistId,
      album_id: albumId
    });
    getSongs();
    clearForm();
  };

  const updateSong = async () => {
    await axios.put(`http://localhost:3001/api/songs/${updateId}`, {
      title,
      duration,
      releaseYear,
      artist_id: artistId,
      album_id: albumId
    });
    getSongs();
    clearForm();
  };

  const deleteSong = async (id) => {
    await axios.delete(`http://localhost:3001/api/songs/${id}`);
    getSongs();
  };

  const clearForm = () => {
    setTitle('');
    setDuration('');
    setReleaseYear('');
    setArtistId('');
    setAlbumId('');
    setUpdateId(null);
  };

  useEffect(() => {
    getSongs();
    getArtistsAndAlbums();
  }, []);

  return (
    <div className="page-container">
      <div className="nav-buttons">
        <Link to="/"><button className="primary-btn">Home</button></Link>
        <Link to="/artists"><button className="primary-btn">Artists</button></Link>
        <Link to="/albums"><button className="primary-btn">Albums</button></Link>
      </div>

      <div className="songs-container">
        <h2>Songs</h2>

        <div className="form-group">
          <input
            className="input-field"
            placeholder="Title"
            value={title}
            onChange={e => setTitle(e.target.value)}
          />
          <input
            className="input-field"
            placeholder="Duration (e.g. 3:45)"
            value={duration}
            onChange={e => setDuration(e.target.value)}
          />
          <input
            className="input-field"
            placeholder="Release Year"
            value={releaseYear}
            onChange={e => setReleaseYear(e.target.value)}
          />
          <select
            className="input-field"
            value={artistId}
            onChange={e => setArtistId(e.target.value)}
          >
            <option value="">Select Artist</option>
            {artists.map(artist => (
              <option key={artist.id} value={artist.id}>
                {artist.name}
              </option>
            ))}
          </select>
          <select
            className="input-field"
            value={albumId}
            onChange={e => setAlbumId(e.target.value)}
          >
            <option value="">Select Album</option>
            {albums.map(album => (
              <option key={album.id} value={album.id}>
                {album.title}
              </option>
            ))}
          </select>
        </div>

        <div className="button-group">
          {updateId ? (
            <button onClick={updateSong} className="add-btn">Update Song</button>
          ) : (
            <button onClick={addSong} className="add-btn">Add Song</button>
          )}
          <button onClick={clearForm} className="clear-btn">Clear</button>
        </div>

        <div className="song-list">
          <h3>All Songs</h3>
          {songs.map((song) => (
            <div key={song.id} className="card">
              <p>
                <strong>{song.title}</strong> – {song.duration} – {song.releaseYear} <br />
                Artist ID: {song.artist_id}, Album ID: {song.album_id}
              </p>
              <button
                className="edit-btn"
                onClick={() => {
                  setTitle(song.title);
                  setDuration(song.duration);
                  setReleaseYear(song.releaseYear);
                  setArtistId(song.artist_id);
                  setAlbumId(song.album_id);
                  setUpdateId(song.id);
                }}
              >
                Edit
              </button>
              <button className="delete-btn" onClick={() => deleteSong(song.id)}>
                Delete
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Songs;
