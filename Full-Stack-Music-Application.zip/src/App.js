import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Artists from './Artists';
import Songs from './Songs';
import Albums from './Albums';
import './style.css';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/artists" element={<Artists />} />
        <Route path="/songs" element={<Songs />} />
        <Route path="/albums" element={<Albums />} />
      </Routes>
    </Router>
  );
}

export default App;
