const express = require('express');
const router = express.Router();
const albumsController = require('../controllers/albumsController');

router.get('/', albumsController.getAllAlbums);
router.post('/', albumsController.createAlbum);
router.put('/:id', albumsController.updateAlbum);
router.delete('/:id', albumsController.deleteAlbum);

module.exports = router;
