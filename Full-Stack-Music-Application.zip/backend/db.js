//const { Pool } = require('pg');
const mysql = require('mysql2');

const pool = mysql.createPool({
    host: 'localhost',
    //user: 'u230448',
    user: 'root',
    database: 'cs230_u230448',
    //password: 'saiv6Fie1Aachi2O',
    password: '',
    port: 3306
  //port: 5432, // Default PostgreSQL port
});

module.exports = pool.promise();
