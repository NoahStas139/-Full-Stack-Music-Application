const express = require('express');
const cors = require('cors');
const app = express();

const artistRoutes = require('./routes/artists'); 
const songRoutes = require('./routes/songs');
const albumRoutes = require('./routes/albums');

app.use(cors());
app.use(express.json());

app.use('/api/artists', artistRoutes); 
app.use('/api/songs', songRoutes);
app.use('/api/albums', albumRoutes);     

const PORT = 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
