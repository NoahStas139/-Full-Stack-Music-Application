const db = require('../db');

// Get all songs
const getAllSongs = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM songs');
    res.json(rows);
  } catch (err) {
    res.status(500).send(err);
  }
};

// Create a new song
const createSong = async (req, res) => {
  const { title, duration, releaseYear, artist_id, album_id } = req.body;
  try {
    await db.query(
      'INSERT INTO songs (title, duration, releaseYear, artist_id, album_id) VALUES (?, ?, ?, ?, ?)',
      [title, duration, releaseYear, artist_id, album_id]
    );
    res.send('Song added');
  } catch (err) {
    res.status(500).send(err);
  }
};

// Update an existing song
const updateSong = async (req, res) => {
  const { title, duration, releaseYear, artist_id, album_id } = req.body;
  const { id } = req.params;
  try {
    await db.query(
      'UPDATE songs SET title = ?, duration = ?, releaseYear = ?, artist_id = ?, album_id = ? WHERE id = ?',
      [title, duration, releaseYear, artist_id, album_id, id]
    );
    res.sendStatus(200);
  } catch (err) {
    res.status(500).send(err);
  }
};

// Delete a song
const deleteSong = async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM songs WHERE id = ?', [id]);
    res.sendStatus(200);
  } catch (err) {
    res.status(500).send(err);
  }
};

module.exports = {
  getAllSongs,
  createSong,
  updateSong,
  deleteSong
};
