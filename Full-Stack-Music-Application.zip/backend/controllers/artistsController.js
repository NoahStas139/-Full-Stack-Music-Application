const db = require('../db');

const getAllArtists = async (req, res) => {
  const [rows] = await db.query('SELECT * FROM artists');
  res.json(rows);
};

const createArtist = async (req, res) => {
  const { name, genre, monthlyListeners } = req.body;
  await db.query(
    'INSERT INTO artists (name, genre, monthlyListeners) VALUES (?, ?, ?)',
    [name, genre, monthlyListeners]
  );
  res.sendStatus(201);
};

const updateArtist = async (req, res) => {
  const { id } = req.params;
  const { name, genre, monthlyListeners } = req.body;
  await db.query(
    'UPDATE artists SET name = ?, genre = ?, monthlyListeners = ? WHERE id = ?',
    [name, genre, monthlyListeners, id]
  );
  res.sendStatus(200);
};

const deleteArtist = async (req, res) => {
  const { id } = req.params;
  await db.query('DELETE FROM artists WHERE id = ?', [id]);
  res.sendStatus(200);
};

module.exports = {
  getAllArtists,
  createArtist,
  updateArtist,
  deleteArtist,
};
