const db = require('../db');

const getAllAlbums = async (req, res) => {
  const [rows] = await db.query('SELECT * FROM albums');
  res.json(rows);
};

const createAlbum = async (req, res) => {
  const { title, releaseYear, artist_id } = req.body;
  try {
    await db.query(
      'INSERT INTO albums (title, releaseYear, artist_id) VALUES (?, ?, ?)',
      [title, releaseYear, artist_id]
    );
    res.send('Album added');
  } catch (err) {
    res.status(500).send(err);
  } 
};

const updateAlbum = async (req, res) => {
  const { id } = req.params;
  const { title, releaseYear, artist_id } = req.body;
  await db.query(
    'UPDATE albums SET title = ?, releaseYear = ?, artist_id = ? WHERE id = ?',
    [title, releaseYear, artist_id, id]
  );
  res.sendStatus(200);
};

const deleteAlbum = async (req, res) => {
  const { id } = req.params;
  await db.query('DELETE FROM albums WHERE id = ?', [id]);
  res.sendStatus(200);
};

module.exports = {
  getAllAlbums,
  createAlbum,
  updateAlbum,
  deleteAlbum,
};
